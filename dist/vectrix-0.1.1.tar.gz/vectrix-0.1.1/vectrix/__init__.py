from .vectrix import VectrixUtils

vectrix = VectrixUtils()
